module.exports = {
   MongoURI: 'mongodb+srv://admin:admin@cluster0.gkwhz.mongodb.net/test?retryWrites=true&w=majority' 
};